import java.util.ArrayList;


//database schema 
public class Attribute {
	String name;
	Value type;
	
	public Attribute(String name, Value type){
		this.name = name;
		this.type = type;
	}
}
