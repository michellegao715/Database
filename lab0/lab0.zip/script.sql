CREATE TABLE Students (StudentID INT, LastName TEXT, FirstName TEXT);
INSERT INTO Students VALUES (123.0, Smith, John);
INSERT INTO Students VALUES (124, Taylor, Swift);
INSERT INTO Students VALUES (125, Emma, Stone);
SELECT LastName from Students;
